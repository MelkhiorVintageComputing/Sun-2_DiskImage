stty dec
set noglob; eval `tset -Q -s`; unset noglob
