#! /bin/sh -
#
#	@(#)rc.boot 1.25 88/03/22 SMI
#
# Executed once at boot time
#
# Note that all "echo" commands are in parentheses.  This is done
# because all commands that redirect the output to "/dev/console"
# must be done in a child of the main shell, so that the main shell
# does not open a terminal and get its process group set.  Since
# "echo" is a builtin command, redirection for it will be done
# in the main shell unless the command is run in a subshell.
#

PATH=/sbin:/single:/usr/bin:/usr/etc; export PATH
HOME=/; export HOME
hostname=sun2

#
# It is important to fsck the root filesystem here
# to prevent spurious panics after system crashes.
#

hostname $hostname
ifconfig ec0 $hostname -trailers up
ifconfig ie0 $hostname -trailers up
ifconfig le0 $hostname -trailers up

#
# This function is used when fsck detects an error and we want to leave
# the file systems mounted read-only to facilitate any needed repair.
#
noremount() {
	(
	echo ""
	echo "WARNING - file systems have NOT been remounted read-write."
	echo "Use fsck to fix any file system problems, rebooting the"
	echo "system if any problems are found with a mounted file system."
	echo "After file systems have fsck'ed cleanly, you can remount file"
	echo "systems and finish single-user setup using \"/etc/rc.single\"."
	)						>/dev/console
}

mount -n -r /usr 					>/dev/console 2>&1

if [ $1x = singleuserx ]; then
	(echo "checking / and /usr filesystems")	>/dev/console
	fsck -p -w / /usr				>/dev/console 2>&1
	error=$?
	what="Fsck"
else
	# trust that everything is ok when /fastboot exists
	# and skip doing the fsck'ing the file systems.
	if [ -r /fastboot ]; then
		(echo "Fast boot ... skipping disk checks")	>/dev/console
		error=0
	else
		(echo "checking filesystems")		>/dev/console
		fsck -p -w				>/dev/console 2>&1
		error=$?
		what="Reboot"
	fi
fi

case $error in
0|2)
	#
	# Everything looks good.
	#
	# Finish the single user setup which will remount the
	# file systems read-write and do other work which can
	# be done only on a writable root file system.
	#
	sh /etc/rc.single
	;;
4)
	if [ $1x = singleuserx ]; then
		(echo "Mounted FS fixed - rebooting single-user.")>/dev/console
		reboot -q -n -- -s
	else
		(echo "Mounted FS fixed - rebooting.")		>/dev/console
		reboot -q -n
	fi
	;;
8)
	(echo "$what failed...help!")				>/dev/console
	noremount
	;;
12)
	(echo "$what interrupted.")				>/dev/console
	noremount
	;;
*)
	(echo "Unknown error in reboot fsck.")			>/dev/console
	noremount
	;;
esac

#
# exit with error status from fsck
#
exit $error
