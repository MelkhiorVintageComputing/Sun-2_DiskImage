umask 2
set path=(. /bin /usr/bin /usr/ucb /etc /usr/etc)
if ( $?prompt ) then
	set history=32
endif
