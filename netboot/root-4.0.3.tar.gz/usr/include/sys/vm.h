/*	@(#)vm.h 2.6 88/02/08 SMI; from UCB 4.3 81/04/23	*/

/*
 *	#include <sys/vm.h>
 * is a quick way to include all the vm header files.
 */
#include <sys/vmparam.h>
#include <sys/vmmac.h>
#include <sys/vmmeter.h>
#include <sys/vmsystm.h>
