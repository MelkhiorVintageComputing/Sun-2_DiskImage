/*	@(#)debug.h 1.8 88/02/08 SMI; from S5R3 sys/debug.h 10.2	*/

/*	Copyright (c) 1984 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#ifndef	_DEBUG_
#define	_DEBUG_

#define	DEBUG

/*
 * When "lint" is being run, don't put the predicate in an "if",
 * so that you don't get complaints about "ASSERT(0);".
 */
#if defined(DEBUG)
# if defined(lint)
#define ASSERT(EX)  assfail("", "", 0)
# else
#define ASSERT(EX) if (!(EX))assfail("EX", __FILE__, __LINE__)
# endif
#else
#define ASSERT(x)
#endif

#endif	_DEBUG_
