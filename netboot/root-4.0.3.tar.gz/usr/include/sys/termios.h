/*	@(#)termios.h 1.8 88/02/08 SMI	*/

#ifndef _TERMIOS_
#define _TERMIOS_

#include <sys/ioccom.h>
#include <sys/ttydev.h>

#define	CTRL(c)	('c'&037)

#define	NCCS	17

/* control characters */
#define	VINTR		0
#define	VQUIT		1
#define	VERASE		2
#define	VKILL		3
#define	VEOF		4
#define	VEOL		5
#define	VEOL2		6
#define	VSWTCH		7
#define	VSTART		8
#define	VSTOP		9
#define	VSUSP		10
#define	VDSUSP		11
#define	VREPRINT	12
#define	VDISCARD	13
#define	VWERASE		14
#define	VLNEXT		15
#define	VSTATUS		16

#define	VMIN		VEOF
#define	VTIME		VEOL

/* default control chars */
#define	CINTR	CTRL(c)
#define	CQUIT	034		/* FS, ^\ */
#define	CERASE	0177		/* DEL, ^? */
#define	CKILL	CTRL(u)
#define	CEOF	CTRL(d)
#define	CEOT	CEOF
#define	CEOL	0
#define	CEOL2	0
#define	CSWTCH	0
#define	CNSWTCH	0
#define	CSTART	CTRL(q)
#define	CSTOP	CTRL(s)
#define	CSUSP	CTRL(z)
#define	CDSUSP	CTRL(y)
#define	CRPRNT	CTRL(r)
#define	CFLUSH	CTRL(o)
#define	CWERASE	CTRL(w)
#define	CLNEXT	CTRL(v)

#define	CESC	'\\'
#define	CNUL	0
#define	CDEL	0377

/* input modes */
#define	IGNBRK	0x00000001
#define	BRKINT	0x00000002
#define	IGNPAR	0x00000004
#define	PARMRK	0x00000008
#define	INPCK	0x00000010
#define	ISTRIP	0x00000020
#define	INLCR	0x00000040
#define	IGNCR	0x00000080
#define	ICRNL	0x00000100
#define	IUCLC	0x00000200
#define	IXON	0x00000400
#define	IXANY	0x00000800
#define	IXOFF	0x00001000
#define	IMAXBEL	0x00002000

/* output modes */
#define	OPOST	0x00000001
#define	OLCUC	0x00000002
#define	ONLCR	0x00000004
#define	OCRNL	0x00000008
#define	ONOCR	0x00000010
#define	ONLRET	0x00000020
#define	OFILL	0x00000040
#define	OFDEL	0x00000080
#define	NLDLY	0x00000100
#define	NL0	0
#define	NL1	0x00000100
#define	CRDLY	0x00000600
#define	CR0	0
#define	CR1	0x00000200
#define	CR2	0x00000400
#define	CR3	0x00000600
#define	TABDLY	0x00001800
#define	TAB0	0
#define	TAB1	0x00000800
#define	TAB2	0x00001000
#define	XTABS	0x00001800
#define	TAB3	XTABS
#define	BSDLY	0x00002000
#define	BS0	0
#define	BS1	0x00002000
#define	VTDLY	0x00004000
#define	VT0	0
#define	VT1	0x00004000
#define	FFDLY	0x00008000
#define	FF0	0
#define	FF1	0x00008000
#define	PAGEOUT	0x00010000
#define	WRAP	0x00020000

/* control modes */
#define	CBAUD	0x0000000f
#define	CSIZE	0x00000030
#define	CS5	0
#define	CS6	0x00000010
#define	CS7	0x00000020
#define	CS8	0x00000030
#define	CSTOPB	0x00000040
#define	CREAD	0x00000080
#define	PARENB	0x00000100
#define	PARODD	0x00000200
#define	HUPCL	0x00000400
#define	CLOCAL	0x00000800
#define	LOBLK	0x00001000
#define	CIBAUD	0x000f0000
#define	CRTSCTS	0x80000000

#define	IBSHIFT	16

/* line discipline 0 modes */
#define	ISIG	0x00000001
#define	ICANON	0x00000002
#define	XCASE	0x00000004
#define	ECHO	0x00000008
#define	ECHOE	0x00000010
#define	ECHOK	0x00000020
#define	ECHONL	0x00000040
#define	NOFLSH	0x00000080
#define	TOSTOP	0x00000100
#define	ECHOCTL	0x00000200
#define	ECHOPRT	0x00000400
#define	ECHOKE	0x00000800
#define	DEFECHO	0x00001000
#define	FLUSHO	0x00002000
#define	PENDIN	0x00004000		/* sigh */

/*
 * Ioctl control packet
 */
struct termios {
	unsigned long	c_iflag;	/* input modes */
	unsigned long	c_oflag;	/* output modes */
	unsigned long	c_cflag;	/* control modes */
	unsigned long	c_lflag;	/* line discipline modes */
	char		c_line;		/* line discipline XXX */
	unsigned char	c_cc[NCCS];	/* control chars */
};

/* codes 1 through 5 are old "termio" calls */
#define	TCXONC		_IO(T, 6)
#define	TCFLSH		_IO(T, 7)
#define	TCGETS		_IOR(T, 8, struct termios)
#define	TCSETS		_IOW(T, 9, struct termios)
#define	TCSETSW		_IOW(T, 10, struct termios)
#define	TCSETSF		_IOW(T, 11, struct termios)
#define	TCSNDBRK	_IO(T, 12)
#define	TCDRAIN		_IO(T, 13)

#include <sys/ttycom.h>

#endif
