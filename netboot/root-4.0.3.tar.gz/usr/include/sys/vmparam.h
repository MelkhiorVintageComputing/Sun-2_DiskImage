/*	@(#)vmparam.h 2.7 88/02/08 SMI; from UCB 4.13 82/12/17	*/

/*
 * Machine dependent constants
 */
#include <machine/vmparam.h>
