/*
 *
 * label - the security label structure
 */
#ifndef BLABEL
#define BLABEL

struct binary_label {
	short	sl_level;
	char	sl_categories[16];
	char	sl_unused[14];
};

typedef struct binary_label blabel_t;

#endif	BLABEL
