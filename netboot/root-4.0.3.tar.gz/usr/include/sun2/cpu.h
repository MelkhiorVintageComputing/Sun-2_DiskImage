/*	@(#)cpu.h 5.17 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

#define	CPU_ARCH	0xf0		/* mask for architecture bits */
#define	SUN2_ARCH	0x00		/* 0 for backwards compatibility */

#define	CPU_MACH	0x0f		/* mask for machine implementation */
#define	MACH_120	0x01		/* generic for Multibus based system */
#define	MACH_50		0x02	 	/* generic for VMEbus based system */

#define	CPU_SUN2_120	(SUN2_ARCH + MACH_120)	/* cpu value for mach 1 */
#define	CPU_SUN2_50	(SUN2_ARCH + MACH_50)	/* cpu value for mach 2 */

#if defined(KERNEL) && !defined(LOCORE)
int cpu;				/* machine type we are running on */
int dvmasize;				/* usable dvma size in clicks */
int fbobmemavail;			/* video copy memory is available */
#endif defined(KERNEL) && !defined(LOCORE)

/*
 * SEGTEMP & SEGTEMP2 are virtual segments reserved for temporary operations.
 * We use the segments immediately before the start of debugger area.
 */
#include <debug/debug.h>
#define	SEGTEMP		((addr_t)(DEBUGSTART - (2 * NBSG)))
#define	SEGTEMP2	((addr_t)(DEBUGSTART - NBSG))

/*
 * Various I/O space related constants
 */
#define	MBMEM_SIZE	0x100000
#define MBIO_SIZE	0x010000
#define VME0_SIZE	0x800000
#define VME8_SIZE	0x800000

#define	VME16_BASE	0xFF0000
#define	VME16_SIZE	(1<<16)
#define	VME16_MASK	(VME16_SIZE-1)

#define	VME24_SIZE	(1<<24)
#define	VME24_MASK	(VME24_SIZE-1)

/*
 * Basic DVMA space sizes for the different implementations.
 * The actual usable dvma size (in clicks) is given by the
 * dvmasize variable declared above.
 */
#define	SUN2_120_DVMASIZE	0x40000
#define	SUN2_50_DVMASIZE	0x100000

/*
 * FBSIZE is the amount of memory we will use for the frame buffer 
 * copy region if the copy mode of the frame buffer is to be used
 */
#define FBSIZE   0x20000	/* size of frame buffer memory region */
#define OBFBADDR 0x100000	/* location of frame buffer in memory */
