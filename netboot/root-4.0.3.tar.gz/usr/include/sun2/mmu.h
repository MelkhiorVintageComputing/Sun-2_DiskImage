/*	@(#)mmu.h 5.16 88/03/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */
#ifndef _MMU_
#define _MMU_

/*
 * Sun-2 memory management.
 *
 * This file gives more mmu specific constants and defines
 * the interface to some pretty low level mmu routines.
 */

/*
 * Process Address space is 24 bits
 */
#define	ADDRESS_MASK	0x00ffffff	/* Mask of valid bits in an address */


/*
 * Hardware context and segment information
 * Mnemonic decoding:
 *	PMENT - Page Map ENTry
 *	PMGRP - Group of PMENTs (aka "segment")
 */
#define	MNCTXS			8	/* Number of mapping contexts */
#define	NPMGRPPERCTX		0x200	/* 512 */
#define	MNPMGRPS		0x100	/* 256 */
#define	NPMENTPERPMGRP		0x10	/* 16 */
#define	NPMENTPERPMGRPSHIFT	4	/* log2(NPMENTPERPMGRP) */

/*
 * Useful defines for hat constants
 */
#define	NCTXS		MNCTXS
#define	NPMGRPS		MNPMGRPS

/*
 * More useful manifest constants
 */
#define	TOTALPMGRP		(NCTXS * NPMGRPPERCTX)
#define	PMGRPSIZE		(NPMENTPERPMGRP * PAGESIZE)
#define	MNPMENTS		(NPMGRPS * NPMENTPERPMGRP)
#define	PMGRP_INVALID		(NPMGRPS - 1)
#define	CTXSIZE			(PMGRPSIZE * NPMGRPPERCTX)
#define	CTXMASK			(NCTXS - 1)
#define	PMGRPOFFSET		(PMGRPSIZE - 1)
#define	PMGRPMASK		(~PMGRPOFFSET)
#define	PMGRPSHIFT		(PAGESHIFT + NPMENTPERPMGRPSHIFT)

/*
 * XXX - Old names for some backwards compatibility
 */
#define	NBSG		PMGRPSIZE
#define	SGOFSET		PMGRPOFFSET
#define	SGSHIFT		PMGRPSHIFT

/*
 * 680x0 function code register values
 */
#define	FC_UD	1		/* user data */
#define	FC_UP	2		/* user program */
#define	FC_MAP	3		/* Sun-2 memory maps */
#define	FC_SD	5		/* supervisor data */
#define	FC_SP	6		/* supervisor program */
#define	FC_CPU	7		/* cpu space */

/*
 * Misc FC_MAP base addresses
 */
#define	PAGE_MAP		0x0		/* long */
#define	SEGMENT_MAP		0x5		/* byte */
#define	CONTEXT_REG		0x7		/* byte */
#define	ID_PROM			0x8		/* byte, step by MMU_PAGESIZE */
#define	DIAGNOSTIC_REG		0xb		/* byte */

#define	CONTROL_MASK		0x00fff800	/* addr mask for cntrl space */

#define	KCONTEXT		0		/* kernel's context number */


#if defined(KERNEL) && !defined(LOCORE)
/*
 * Low level functions for mmu specfic operations
 */
struct	ctx *mmu_getctx();
void	mmu_setctx(/* ctx */);
void	mmu_setpmg(/* base, pmg */);
void	mmu_settpmg(/* base, pmg */);
struct	pmgrp *mmu_getpmg(/* base */);
void	mmu_setpte(/* base, pte */);
void	mmu_getpte(/* base, ppte */);
void	mmu_getkpte(/* base, ppte */);
void	mmu_pmginval(/* pmg */);

/*
 * No virtual address cache for sun2, so we ifdef out the vac flush routines
 */
#define	vac_init()
#define	vac_flushall()
#define	vac_ctxflush()
#define	vac_segflush(base)
#define	vac_pageflush(base)
#define	vac_flush(base, len)

/*
 * Since there is no vac, bp_alloc() is always just a call to rmalloc()
 */
#define bp_alloc(map, bp, size)		(int)rmalloc((map), (long)(size))

void	sun_setcontrol_long(/* space, addr */);
u_int	sun_getcontrol_long(/* space, addr, value */);
void	sun_setcontrol_byte(/* space, addr */);
u_int	sun_getcontrol_byte(/* space, addr, value */);
#endif defined(KERNEL) && !defined(LOCORE)

#endif !_MMU_
