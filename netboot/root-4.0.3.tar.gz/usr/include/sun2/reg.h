/*      @(#)reg.h 1.2 88/02/08 SMI      */

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */



#ifndef _REG_
#define _REG_

#include <m68k/reg.h>

#endif !_REG_

