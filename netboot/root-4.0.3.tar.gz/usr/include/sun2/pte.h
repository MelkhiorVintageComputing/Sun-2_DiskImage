/*	@(#)pte.h 5.13 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

/*
 * Sun-2 hardware page table entry
 */

#ifndef	_PTE_
#define	_PTE_

#ifndef	LOCORE
struct pte {
	unsigned int	pg_v:1;		/* valid bit */
	unsigned int	pg_prot:6;	/* access control */
	unsigned int	:1;
	unsigned int	pg_type:2;	/* page type */
	unsigned int	pg_r:1;		/* referenced */
	unsigned int	pg_m:1;		/* modified */
	unsigned int	:8;
	unsigned int	pg_pfnum:12;	/* page frame number */
};
#endif	!LOCORE

#define	PG_V		0x80000000
#define	PG_R		0x00200000
#define	PG_M		0x00100000
#define	PG_PFNUM	0x00c00fff	/* page # mask - XXX includes type */

#define	KW		070
#define	KR		050
#define	UW		077
#define	UR		055

#define	MAKE_PROT(v)	((v) << 25)
#define	PG_PROT		MAKE_PROT(077)
#define	PG_KW		MAKE_PROT(KW)
#define	PG_KR		MAKE_PROT(KR)
#define	PG_UW		MAKE_PROT(UW)
#define	PG_UR		MAKE_PROT(UR)
#define	PG_UPAGE	PG_KW		/* sun2 u pages not user accessable */

#define	OBMEM		0x0
#define	OBIO		0x1
#define	MBMEM_VME0	0x2
#define	MBMEM		0x2
#define	VME0		0x2
#define	MBIO_VME8	0x3
#define	MBIO		0x3
#define	VME8		0x3

#define	MAKE_PGT(v)	((v) << 22)
#define	PGT_MASK	MAKE_PGT(0x3)
#define	PGT_OBMEM	MAKE_PGT(OBMEM)
#define	PGT_OBIO	MAKE_PGT(OBIO)

#define	PGT_MBMEM	MAKE_PGT(MBMEM)		/* cpu == CPU_SUN2_120 */
#define	PGT_VME0	MAKE_PGT(VME0)		/* cpu == CPU_SUN2_50 */
#define	PGT_DVMABUS	MAKE_PGT(MBMEM_VME0)
#define	PGT_MBMEM_VME0	MAKE_PGT(MBMEM_VME0)

#define	PGT_MBIO	MAKE_PGT(MBIO)		/* cpu == CPU_SUN2_120 */
#define	PGT_VME8	MAKE_PGT(VME8)		/* cpu == CPU_SUN2_50 */
#define	PGT_MBIO_VME8	MAKE_PGT(MBIO_VME8)

/*
 * This macro can be used to convert a struct pte * in to the relevant
 * bits needed for things like mapin and cdevsw[] mmap routine which
 * still deal with integers.  Effectively for the Sun-2 this macro is
 * really implementing the following expression more effectively:
 *
 *	(MAKE_PGT((pte)->pg_type) | (pte)->pg_pfnum)
 */
#define	MAKE_PFNUM(pte)	((*(unsigned int *)(pte)) & PG_PFNUM)

/*
 * For a Sun-2, a "valid" pte must have the valid bit on and some protections
 */
#define	pte_valid(pte)	((pte)->pg_v != 0 && (pte)->pg_prot != 0)

#if !defined(LOCORE) && defined(KERNEL)
/* utilities defined in locore.s */
extern	struct pte Sysmap[];
extern	char Sysbase[];
extern	struct pte Forkmap[];
extern	struct pte mmap[];
extern	struct pte msgbufmap[];
extern	struct pte CMAP1[];
extern	char CADDR1[];
extern	struct pte CMAP2[];
extern	char CADDR2[];
extern	char Syslimit[];

/*
 * These defines are just here to be an aid
 * for someone that was using these defines.
 */
#define	Usrptmap	Sysmap
#define	usrpt		Sysbase

extern	struct pte mmu_pteinvalid;
#endif !defined(LOCORE) && defined(KERNEL)
#endif !_PTE_
