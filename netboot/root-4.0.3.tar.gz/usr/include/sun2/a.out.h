/*      @(#)a.out.h 1.2 88/03/06 SMI; from UCB 4.1 83/05/03       */

/* The Sun-2 a.out.h is identical to the Sun-3 a.out.h. */
#include "../sun3/a.out.h"
