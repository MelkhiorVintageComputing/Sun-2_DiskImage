/*	@(#)setjmp.h 1.2 88/03/06 SMI; from UCB 4.1 83/05/03	*/

/* The Sun-2 setjmp.h is identical to the Sun-3 setjmp.h. */
#include "../sun3/setjmp.h"
