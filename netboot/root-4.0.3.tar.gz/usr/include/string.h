/*	@(#)string.h 1.4 88/02/07 SMI; from S5R2 1.2	*/

extern char
	*strcpy(),
	*strncpy(),
	*strcat(),
	*strncat(),
	*strchr(),
	*strrchr(),
	*strpbrk(),
	*strtok(),
	*strdup();
extern int
	strcmp(),
	strncmp(),
	strlen(),
	strspn(),
	strcspn();
