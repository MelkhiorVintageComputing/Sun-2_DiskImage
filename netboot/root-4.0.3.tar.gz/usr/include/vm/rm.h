/*	@(#)rm.h	1.11 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

#ifndef _vm_rm_h
#define _vm_rm_h

/*
 * VM - Resource Management.
 */

struct	page *rm_allocpage(/* seg, addr */);
void	rm_outofanon();
void	rm_outofhat();
size_t	rm_asrss(/* as */);
#endif !_vm_rm_h
