/*	@(#)vpage.h	1.7 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

#ifndef _vm_vpage_h
#define _vm_vpage_h
/*
 * VM - Information per virtual page.
 */
struct vpage {
	u_int	vp_prot: 4;		/* see <sys/mman.h> prot flags */
	u_int	vp_advise: 3;		/* see <sys/mman.h> madvise flags */
	u_int	vp_lock: 1;		/* someone has this vpage locked  */
	u_int	vp_want: 1;		/* someone wants this vpage */
	u_int	vp_ref: 1;		/* reference bit */
	u_int	vp_mod: 1;		/* (maybe) modify bit, from hat */
	u_int	: 5;
};

int	vpage_lock(/* l, vp */);
void	vpage_unlock(/* l, vp */);
#endif _vm_vpage_h
