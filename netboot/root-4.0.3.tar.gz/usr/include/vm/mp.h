/*	@(#)mp.h	1.9 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

#ifndef _vm_mp_h
#define _vm_mp_h

/*
 * VM - multiprocessor/ing support.
 *
 * Currently the mon_enter() / mon_exit() pair implements a
 * simple monitor for objects protected by the appropriate lock.
 * The cv_wait() / cv_broadcast pait implements a simple
 * condition variable which can be used for `sleeping'
 * and `waking' inside a monitor if some resource
 * is needed which is not available.
 */

typedef struct mon_t {
	u_char	dummy;
} mon_t;

void	mon_enter(/* lk */);
void	mon_exit(/* lk */);
void	cv_wait(/* lk, cond */);
void	cv_broadcast(/* lk, cond */);

#define	lock_init(lk)	(lk)->dummy = 0
#endif !_vm_mp_h
