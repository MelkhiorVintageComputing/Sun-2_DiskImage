/*	@(#)cpu.h 1.4 88/08/12 SMI	*/

/*
 * Copyright (c) 1986 by Sun Microsystems, Inc.
 */

#ifndef LOCORE
#include <mon/sunromvec.h>
#endif !LOCORE

#ifndef CPU_H

#define	CPU_ARCH	0xf0		/* mask for architecture bits */
#define	SUN4_ARCH	0x20		/* arch value for Sun 4 */

#define	CPU_MACH	0x0f		/* mask for machine implementation */
#define	MACH_260	0x01
#define	MACH_110	0x02
#define MACH_330	0x03
#define MACH_460	0x04

#define CPU_SUN4_260	(SUN4_ARCH + MACH_260)
#define CPU_SUN4_110	(SUN4_ARCH + MACH_110)
#define CPU_SUN4_330	(SUN4_ARCH + MACH_330)
#define CPU_SUN4_460	(SUN4_ARCH + MACH_460)

#if defined(KERNEL) && !defined(LOCORE)
extern int cpu;				/* machine type we are running on */
extern int dvmasize;			/* usable dvma size in clicks */
extern int vac;				/* there is a virtual address cache */
#ifdef SUN4_460
extern int iocenable;			/* is iocache enabled */
#endif SUN4_460
#endif

#endif !CPU_H
