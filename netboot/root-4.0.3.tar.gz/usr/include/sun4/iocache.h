/*
 * @(#)iocache.h 1.1 88/09/13 SMI 
 */

/*
 * iocache related defintions.
 */
#define IOC_CACHE_LINES		0x80	/* Num  cache lines in the iocache  */

#define	IOC_DATA_ADDR		0xFFFEC000	/* virtual addr for ioc data */
#define	IOC_TAGS_ADDR		0xFFFED000	/* virtual addr for ioc tag  */
#define	IOC_FLUSH_ADDR		0xFFFEE000	/* virtual addr for ioc flush */

#define	OBIO_IOCFLUSH_ADDR 	0xEE004000	/* address of ioc flush */
#define	OBIO_IOCDATA_ADDR 	0xEE006000	/* address of ioc data 	*/
#define	OBIO_IOCTAG_ADDR 	0xEE007000	/* address of ioc tag 	*/

#define IOC_LINESIZE            32
#define IOC_LINEMASK            (IOC_LINESIZE-1)
#define IOC_PAGENUM             0xFE000         /* Page number mask addres */
#define IOC_PAGENUMBITS         0xD             /* shift to align page num */

#define get_pagenum(x)  	((x&IOC_PAGENUM) >> IOC_PAGENUMBITS)
                                                /* macro to obtain page num */
#define ioc_sizealign(x)        ((((x) + IOC_LINESIZE - 1) / IOC_LINESIZE) \
                                    * IOC_LINESIZE)
#define ioc_padalign(x)         (ioc_sizealign(x) - (x))

#define	IOC_ETHER_IN		0x7E		/* line for ethernet input */
#define	IOC_ETHER_OUT		0x7F		/* line for ethernet output */
