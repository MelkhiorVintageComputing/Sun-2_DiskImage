/*	@(#)setjmp.h 1.2 88/03/06 SMI; from UCB 4.1 83/05/03	*/

#ifndef _SETJMP_
#define _SETJMP_

/*
 * onsstack,sigmask,sp,pc,npc,psr,g1,o0,wbcnt (sigcontext).
 * All else recovered by under/over(flow) handling.
 */
#define	_JBLEN	9

extern int sigsetjmp(), setjmp(), _setjmp();
extern void siglongjmp(), longjmp(), _longjmp();

/*
 * Routines that call setjmp have strange control flow graphs,
 * since a call to a routine that calls resume/longjmp will eventually
 * return at the setjmp site, not the original call site.  This
 * utterly wrecks control flow analysis.
 */
#pragma unknown_control_flow(sigsetjmp, setjmp, _setjmp)

typedef int jmp_buf[_JBLEN];

/*
 * One extra word for the "signal mask saved here" flag.
 */
typedef	int sigjmp_buf[_JBLEN+1];

#endif /*_SETJMP_*/
