/*      @(#)grpadj.h 1.3 88/02/07 SMI      */ /* c2 secure */

struct	group_adjunct { /* see getgraent(3) */
	char	*gra_name;
	char	*gra_passwd;
};

struct group_adjunct *getgraent(), *getgragid(), *getgranam();
