/*	@(#)sgtty.h 1.6 88/02/07 SMI; from UCB 4.2 85/01/03	*/

#ifndef	_IOCTL_
#include <sys/ioctl.h>
#endif
