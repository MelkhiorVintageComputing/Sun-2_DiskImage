/*	@(#)xdvar.h 1.14 88/12/12 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */
#ifndef _XDVAR_
#define _XDVAR_

/*
 * Structure definitions for Xylogics 7053 disk driver.
 */
#include <sundev/xdcreg.h>
#include <sundev/xdreg.h>
#include <sundev/xycom.h>

/*
 * Structure needed to execute a command.  Contains controller & iopb ptrs
 * and some error recovery information.  The link is used to identify
 * chained iopbs.
 */
struct xdcmdblock {
	struct	xdctlr *c;		/* ptr to controller */
	struct	xdunit *un;		/* ptr to unit */
	struct	xdiopb *iopb;		/* ptr to IOPB */
	struct	xdcmdblock *next;	/* next iopb in queue */
	struct	buf *breq;		/* */
	caddr_t	mbaddr;			/* */
	u_char	retries;		/* retry count */
	u_char	restores;		/* restore count */
	u_char	resets;			/* reset count */
	u_char  slave;			/* current drive no. */
	u_short	cmd;			/* current command */
	int	flags;			/* state information */
	caddr_t	baddr;			/* physical buffer address */
	daddr_t	blkno;			/* current block */
	daddr_t	altblkno;		/* alternate block (forwarding) */
	u_short	nsect;			/* sector count active */
	short	device;			/* current minor device */
	u_char	failed;			/* command failure */
};

/*
 * Data per unit
 */
struct xdunit {
	struct	xdctlr *c;		/* controller */
	struct	dk_map *un_map;		/* logical partitions */
	struct	dk_geom *un_g;		/* disk geometry */
	struct	buf *un_rtab;		/* for physio */
	int	un_ltick;		/* last time active */
	struct	mb_device *un_md;	/* generic unit */
	struct	mb_ctlr *un_mc;		/* generic controller */
	struct	dkbad *un_bad;		/* bad sector info */
	int	un_errsect;		/* sector in error */
	u_char	un_errno;		/* error number */
	u_char	un_errsevere;		/* error severity */
	u_short	un_errcmd;		/* command in error */
	u_char	un_flags;		/* state information */
};

/*
 * Data per controller
 */
struct xdctlr {
	struct	xdunit *c_units[XDUNPERC];	/* units on controller */
	struct	xddevice *c_io;			/* ptr to I/O space data */
	struct	xdcmdblock *actvcmdq; 		/* current command queue */
	struct	xdiopb *rdyiopbq;		/* ready iopbs */
	struct	xdiopb *lrdy;			/* last ready iopb */
	int	c_wantint;			/* controller is busy */
	int	c_intpri;			/* interrupt priority */
	int	c_intvec;			/* interrupt vector */
	u_char	c_flags;			/* state information */
};

/*
 * after RIO is found to be set, this is the number of
 * seconds to wait for the interrupt handler to get invoked
 * before timing out and invoking xdintr via the
 * watch-dog handler.  This value was originally set to
 * 1, but this resulted in recovery messages being printed
 * out constantly under conditions of heavy I/O.
 */
#define MAX_RIO_TICKS 10	 
				

struct xd_w_info {
	u_int curr_timeout;     /* remaining ticks in interval */
        u_int next_timeout;     /* ticks for next interval */
	u_int got_interrupt;    /* got an interrupt in interval */
	u_int got_rio;		/* number of seconds XD_RIO */
				/* has been set, but not serviced */
};

#endif _XDVAR_

