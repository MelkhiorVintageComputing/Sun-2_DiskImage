/*      @(#)dbio.h 1.1 88/07/29 SMI      */

/*
 * Copyright (c) 1988 by Sun Microsystems, Inc.
 */

/* Dialbox related macros. See also <sundev/vuid_event.h> */
#ifndef DIAL_DEVID
#define DIAL_DEVID 0x7b
#endif

#ifndef _sundev_dbio_h
#define _sundev_dbio_h

/* DELTA event for a particular dial */
#define DIAL_DELTA(dialnum)     (vuid_first(DIAL_DEVID) + (dialnum))

/* Macro to extract dial number from event */
#define DIAL_NUMBER(event_code)	(event_code & 0xFF)

#define	event_is_dial(event)	(vuid_in_range(DIAL_DEVID, event->ie_code))

/* Dial deltas are in 64ths of degrees, convert to degrees */
#define DIAL_TO_DEGREES(n)	((float)(n) / 64.0)

#define DIAL_UNITS_PER_CYCLE (64*360)

#endif _sundev_dbio_h
