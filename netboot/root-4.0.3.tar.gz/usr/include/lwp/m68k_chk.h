/* @(#) check1.h 1.2 88/02/08 Copyr 1987 Sun Micro */
/* Copyright (C) 1987. Sun Microsystems, Inc. */
/*
 * Compare sp to its lowest legal point.
 * If the stack exceeds its bounds, set a value and return.
 * This macro can be used in procedures used by a lwp to check the
 * integrity of the stack (protect against bumping into another lwp's stack).
 * The overhead (STKOVERHEAD) is silently allocated IN ADDITION TO
 * the amount specfied in lwp_create.
 * This ensures that even if CHECK just barely
 * succeeds, there is room to call the next procedure in most cases
 * without trashing anyone else's stack.
 * This only fails when you're up against the limit and
 * the next procedure has lots of arguments.
 * If you never call a procedure with more than 100 bytes of arguments or so,
 * there should be no problem.
 * Roughly, what we have here:
 *	register unsigned sp;
 *	if (sp <= (unsigned)((int)__CurStack + STKOVERHEAD)) {
 *		location = result;
 *		return;
 *	}
 * Note that this macro depends upon the definitions in machdep.h.
 * This macro is only useful when no mmgt-assisted red-zones are available.
 *
 * The program checkassym.c generates the macro.
 */
extern char *__CurStack;
#define CHECK(location, result) {			\
	asm ("movl ___CurStack, d0");			\
	asm ("addl #6048, d0");				\
	asm ("cmpl d0, sp");				\
	asm ("jhi 1f");					\
	location = result;				\
	asm ("unlk a6");				\
	asm ("rts");					\
	asm ("1:");					\
}
