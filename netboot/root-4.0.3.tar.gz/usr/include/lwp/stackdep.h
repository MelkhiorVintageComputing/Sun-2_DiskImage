/* @(#) stk.h 1.7 88/02/08 Copyr 1987 Sun Micro */

#ifndef __STACKDEP_H__
#define __STACKDEP_H__

#ifdef mc68000
#include <lwp/m68k_stackdep.h>
#endif mc68000

#ifdef vax
#include <lwp/vax_stackdep.h>
#endif vax

#ifdef sparc
#include <lwp/sparc_stackdep.h>
#endif sparc

#define	STKTOP(s) (STACKTOP((s), sizeof(s) / sizeof(stkalign_t)))
extern stkalign_t *lwp_newstk();

#endif __STACKDEP_H__
