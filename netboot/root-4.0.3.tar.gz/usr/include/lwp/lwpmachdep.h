/* @(#) mch.h 1.3 88/02/08 Copyr 1987 Sun Micro */

#ifdef mc68000
#include <lwp/m68k_machdep.h>
#endif mc68000

#ifdef vax
#include <lwp/vax_machdep.h>
#endif vax

#ifdef sparc
#include <lwp/sparc_machdep.h>
#endif sparc
