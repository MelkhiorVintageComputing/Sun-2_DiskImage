/* @(#) lwpmachdep1.h 1.7 88/02/08 Copyr 1987 Sun Micro */
/* Copyright (C) 1987. Sun Microsystems, Inc. */

#ifndef __LWPMACHDEP_H__
#define __LWPMACHDEP_H__

#ifndef WSTOPPED
#include <sys/wait.h>
#endif WSTOPPED

#ifndef _TIME_
#include <sys/time.h>
#endif _TIME_

#ifndef RUSAGE_SELF
#include <sys/resource.h>
#endif RUSAGE_SELF

/* info from SIGCHLD event */
typedef struct sigchldev_t {
	eventinfo_t sigchld_event;      /* general event info, MUST BE FIRST */
	int sigchld_pid;                /* pid of process that changed */
	union wait sigchld_status;      /* status from wait3 */
	struct rusage sigchld_rusage;   /* rusage from wait3 */
} sigchldev_t;

#define	MC_GENERALREGS	12	/* d2-d7, a2-a7 */
#define	MC_TEMPREGS	6	/* d0, d1, a0, a1, pc, ps */

typedef struct machstate_t {
	int mc_generals[MC_GENERALREGS]; /* d2-d7, a2-a7 */
	int mc_temps[MC_TEMPREGS]; /* d0, d1, a0, a1, pc, ps */
} machstate_t;

#endif __LWPMACHDEP_H__
#ifndef	MINSTACKSZ
#define	MINSTACKSZ	1512
#endif	MINSTACKSZ
