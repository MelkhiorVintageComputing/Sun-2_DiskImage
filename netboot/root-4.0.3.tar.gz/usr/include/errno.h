/*	@(#)errno.h 1.3 88/02/07 SMI; from S5R2 1.2	*/

/*
 * Error codes
 */

#include <sys/errno.h>
extern int errno;
