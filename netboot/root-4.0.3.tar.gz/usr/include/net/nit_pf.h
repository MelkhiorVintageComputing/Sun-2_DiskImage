/*	@(#)nit_pf.h 1.3 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

#ifndef	_NIT_PF_
#define	_NIT_PF_

/*
 * Definitions for the streams packet filter module.
 */

#define NIOCSETF	_IOW(p, 2, struct packetfilt)	/* set packet filter */

#endif	_NIT_PF_
