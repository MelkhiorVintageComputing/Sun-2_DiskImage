/*	@(#)alloca.h	1.3	88/02/07	SMI	*/
#if defined(sparc)
# define alloca(x) __builtin_alloca(x)
#endif
