/*	@(#)seg_u.h	1.3 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

/*
 * VM - U-area segment management
 *
 * This file contains definitions related to the u-area segment type.
 *
 * This segment type is not yet implemented.  The intent is that the
 * things defined here evolve into the seg_u implementation.
 */

#ifndef	_sun_seg_u_h
#define	_sun_seg_u_h

/*
 * Private segment information for seg_u.
 *
 * At this stage of the implementation, we record only things that
 * formerly were part of the proc structure.
 *
 * XXX:	The parallel su_uaddr and su_swaddr arrays should perhaps
 * 	be combined into a single array of structures, but doing
 *	so requires more changes to genassym.c et al.
 *
 * N.B.: UPAGES is expressed in units of mmu pages.
 */
struct segu_data {
	long	su_uaddr[UPAGES/CLSIZE];	/* XXX - really struct pte for
						   u area */
	struct	anon *su_swaddr[UPAGES/CLSIZE];	/* disk address of u area when
						   swapped */
};

#ifdef	KERNEL
extern struct seg	segu;
extern struct segu_data	*segudata;

u_int	segu_swapout(/* sup */);
u_int	segu_swapin(/* sup */);
#endif	KERNEL

#endif	_sun_seg_u_h
