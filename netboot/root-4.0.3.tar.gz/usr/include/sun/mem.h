/*	@(#)mem.h 1.3 88/02/08 SMI	*/

/*
 * Copyright (c) 1987 by Sun Microsystems, Inc.
 */

/*
 * Memory Device Minor Numbers
 */
#define	M_MEM		0	/* /dev/mem - physical main memory */
#define	M_KMEM		1	/* /dev/kmem - virtual kernel memory & I/O */
#define	M_NULL		2	/* /dev/null - EOF & Rathole */
#define	M_MBMEM		3	/* /dev/mbmem - Multibus memory space (1 Meg) */
#define	M_MBIO		4	/* /dev/mbio - Multibus I/O space (64k) */
#define M_VME16D16	5	/* /dev/vme16d16 - VME 16bit addr/16bit data */
#define M_VME24D16	6	/* /dev/vme24d16 - VME 24bit addr/16bit data */
#define M_VME32D16	7	/* /dev/vme32d16 - VME 32bit addr/16bit data */
#define M_VME16D32	8	/* /dev/vme16d32 - VME 16bit addr/32bit data */
#define M_VME24D32	9	/* /dev/vme24d32 - VME 24bit addr/32bit data */
#define M_VME32D32	10	/* /dev/vme32d32 - VME 32bit addr/32bit data */
#define M_EEPROM	11	/* /dev/eeprom - on board eeprom device */
#define	M_ZERO		12	/* /dev/zero - source of private memory */
#define	M_ATBUS		13	/* /dev/at - AT bus space */
#define	M_WEITEK	14	/* /dev/weitek - weitek floating point proc */
