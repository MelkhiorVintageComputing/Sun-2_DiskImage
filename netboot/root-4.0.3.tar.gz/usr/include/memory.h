/*	@(#)memory.h 1.3 88/02/07 SMI; from S5R2 1.2	*/

extern char
	*memccpy(),
	*memchr(),
	*memcpy(),
	*memset();
extern int memcmp();
