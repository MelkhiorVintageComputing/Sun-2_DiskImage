/*
 * bootparam.h
 *
 * @(#)bootparam.h 1.6 88/04/18 SMI
 * Copyright (c) 1986 by Sun Microsystems, Inc.
 */

/*
 * Constants for stand-alone I/O (bootstrap) code.
 */
#ifdef sun4
#define	BBSIZE   (64*512) /* Boot block size.               */
#ifdef CACHE
#define LOADADDR 0x20000  /* Load address of boot programs. */
#else CACHE
#define LOADADDR 0x4000   /* Load address of boot programs. */
#endif CACHE
#else sun4
#define BBSIZE   8192     /* Boot block size.               */
#define LOADADDR 0x4000   /* Load address of boot programs. */
#endif sun4

#define	DEV_BSIZE 512
