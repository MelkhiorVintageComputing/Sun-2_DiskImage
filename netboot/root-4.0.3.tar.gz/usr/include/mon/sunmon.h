/* 
 * sunmon.h
 *
 * @(#)sunmon.h 1.6 88/04/18 SMI
 * Copyright (c) 1986 by Sun Microsystems, Inc.
 */

#ifdef sun2
#include "../sun2/sunmon.h"
#endif 

#ifdef sun3
#include "../sun3/sunmon.h"
#endif 

#ifdef sun3x
#include "../sun3x/sunmon.h"
#endif

#ifdef sun4 
#include "../sun4/sunmon.h"
#endif 
