/*	@(#)tiuser.h 1.3 88/02/07 SMI ; from S5R3 1.1 */

/*	Copyright (c) 1984 AT&T	*/
/*	  All Rights Reserved  	*/

/*	THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF AT&T	*/
/*	The copyright notice above does not evidence any   	*/
/*	actual or intended publication of such source code.	*/

#ident	"@(#)head:tiuser.h	1.1"

/*
 * TLI user interface definitions.
 */

#include <nettli/tiuser.h>

