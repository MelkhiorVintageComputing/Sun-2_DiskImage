stty dec
PATH=.:/bin:/usr/bin:/usr/ucb:/etc:/usr/etc:/usr/etc/install
export PATH TERM
